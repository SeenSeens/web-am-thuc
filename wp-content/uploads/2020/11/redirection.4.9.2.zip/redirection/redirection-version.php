<?php

define( 'REDIRECTION_VERSION', '4.9.2' );
define( 'REDIRECTION_BUILD', 'b1c9e2f6a1c3f8b6cc251a44757c6863' );
define( 'REDIRECTION_MIN_WP', '4.6' );
